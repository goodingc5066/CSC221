"""
Chrystian Gooding
9/11/2020
M3HW1
"""

import pandas as pd

df = pd.read_csv('TitanicSurvival.csv'
                 )

df

