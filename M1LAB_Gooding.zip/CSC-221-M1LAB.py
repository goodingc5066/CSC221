# -*- coding: utf-8 -*-
"""
Created on Wed Aug 26 10:47:09 2020

# CSC 221
# M1LAB
# Chrystian Gooding
# 8/26/2020

#Simple game as warmup for rock paper scissors
"""
import random

def playGame():
    # rules: each side picks 1-3, high wins
    #player picks a number
    print ("Please choose a number from 1 to 3:")
    playerChoice = int(input())
    print("You chose", playerChoice)
    #computer picks a number
    cpuChoice = random.randrange(1,3)
    print("OK, I've chosen my number.")
    print("I chose", cpuChoice)
    
    if playerChoice > cpuChoice:
        print("You win!")
    elif cpuChoice > playerChoice:
        print("You lose")
    else:
        print("it's a tie")
    
def main():
    # start the game
    playAgain = 'y'
    while (playAgain =='y'):
        playGame()
        playAgain = input ("Play again? (y/n)")
    
    print("Goodbye!")
# start program
main()

