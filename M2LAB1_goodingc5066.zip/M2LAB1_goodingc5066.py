# -*- coding: utf-8 -*-
# Chrystian Gooding
#8/22/2020
#CSC 221
# M2LAB1 - Student Records

# Class for Student Records
class Student(object):
    """ this class represents a student record."""
    
    def __init__ (self, firstName, lastName, major, studentId, gpa):
        self.firstname = firstName
        self.lastName = lastName
        self.major = major
        self.studentId = studentId
        self.gpa = gpa
        
        
    def __str__(self):
        """prints out a string representation of the object"""
        rep = "Student:" + self.firstname+ " " +self.lastName
        rep += " |Major:" +self.major 
        rep += (" |ID#:" + str (self.studentId))
        rep += (" |GPA:" +str(self.gpa ))
        return rep 
    
def main():
    """ test code to see if the class works"""
    student1 = Student("Sarah", "Smith", "Art", 111999, 3.9)
    print(student1)
    print("_______________________________________________________")
    student2 = Student("Bob", "Wake", "Science", 404001, 1.6)
    print(student2)

main()       





