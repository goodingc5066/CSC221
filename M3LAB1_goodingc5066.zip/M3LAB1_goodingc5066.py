# -*- coding: utf-8 -*-
"""
Created on Wed Nov  4 12:39:19 2020
Chrystian Gooding
11/4/2020
M3LAB1
File Input/Output
"""
import json
import csv

with open('grades.txt', mode='w') as grades:
    grades.write('1 Red A\n')
    grades.write('2 Green B\n')
    grades.write('3 White A\n')
    
with open('grades.txt', 'r') as grades:
    print(f'{"ID":<4}{"Name":<7}{"Grade"}')
    for record in grades:
        student_id, name, grade = record.split()
        print(f'{student_id:<4}{name:<7}{grade}')
        
grades_dict = {'gradebook':
    [{'student_id': 1, 'name': 'Red', 'grade': "A"},
     {'student_id': 2, 'name': 'Green', 'grade': "B"},
     {'student_id': 3, 'name': 'White', 'grade': "A"}]}
    
with open('grades.json', 'w') as grades:
    json.dump(grades_dict, grades)

with open('grades.json', 'r') as grades:
    print(json.dumps(json.load(grades), indent =4))


with open('grades.csv', mode ='w', newline='') as grades:
    writer = csv.writer(grades)
    writer.writerow([1, 'Red', 'A'])
    writer.writerow([2, 'Green', 'B'])
    writer.writerow([3, 'White', 'A'])
    
with open('grades.csv', 'r', newline='') as grades:
    print(f'{"ID":<4}{"Name":<7}{"Grade"}')
    reader = csv.reader(grades)
    for record in reader:
        student_id, name, grade = record
        print(f'{student_id:<4}{name:<7}{grade}')
        
        
        
        
        