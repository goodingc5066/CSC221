# -*- coding: utf-8 -*-
"""
Created on Tue Dec  1 14:10:40 2020
# This program stops words from Romeo and Juliet and then makes a bar chartwith 
the most frequient words
# 12/1/2020
# CSC221 M4HW – FrqBarChart
# Chrystian Gooding
"""

#allows user to import files from other path areas
from pathlib import Path
# imports textblob module
from textblob import TextBlob
#imports nltk module
import nltk
"""
STOPWORDS
"""
#downloads stopwords from nltk module
nltk.download('stopwords')
#imports stopwords mofule from nltk module
from nltk.corpus import stopwords
# assigns english and the language for the stopwords module
stops = stopwords.words('english')
#assigns the RomeoAndJuliet txt file as the textblob
blob = TextBlob(Path('RomeoAndJuliet.txt').read_text())
"""
Copy and paste the line below after running program 
in console to show rusults of stopwords
"""
[word for word in blob.words if word not in stops]
"""
20 word frequency bar chart
"""
# assigns english and the language for the stopwords module
stop_words = stopwords.words('english')
# assigns all words to items
items = blob.word_counts.items()
# counts for the top 20 most used words
items = [item for item in items if item[0] not in stop_words]
# imports item getter
from operator import itemgetter
#sorts items
sorted_items = sorted(items, key=itemgetter(1), reverse=True)
#assigns the top 20 words to top20
top20 = sorted_items[1:21]
#imports pandas as pd
import pandas as pd
# crates a bar chart from top 20 and assigns word and count as labels
df = pd.DataFrame(top20, columns=['word', 'count'])

axes = df.plot.bar(x='word', y='count', legend=False)

import matplotlib.pyplot as plt

plt.gcf().tight_layout()



