# -*- coding: utf-8 -*-
"""
Created on Wed Oct  7 12:12:43 2020
Chrystian Gooding
10/6/2020
M2HW1
This program will run a simple classes and inheritence example.
"""
from commissionemployee import CommissionEmployee



class SalariedCommissionEmployee(CommissionEmployee):
    """ An employee who gets paid a salary plus commission based on gross
    sales."""
    
    def __init__(self, first_name, last_name, ssn, gross_sales, commission_rate,
                 base_salary):
        """Initialize SalariedCommissionEmployee's attributes."""
        super().__init__(first_name, last_name, ssn, gross_sales, 
             commission_rate)
        self.base_salary = base_salary #validate via property
        
    @property
    def base_salary(self):
        return self._base_salary
    
    @base_salary.setter
    def base_salary(self, salary):
        
        if salary < Decimal('0.00'):
            raise ValueError('Base salary must be >= to 0')
            
        self._base_salary = salary
        
    def earnings(self):
        
        return super().earnings() + self.base_salary
    
    def __repr__(self):
        
        return('Salaried' + super().__repr__() +
               f'\nbase salary: {self.base_salary:.2f}')

def main():
    
    s = SalariedCommissionEmployee('Bob', 'Lewis', '444-44-4444',
         Decimal('5000.00'), Decimal('0.04'), Decimal('300.00'))
    print(s.first_name, s.last_name, s.ssn, s.gross_sales, s.commission_rate,
          s.base_salary)
    print(f'{s.earnings():,.2f}')
    
    s.gross_sales = Decimal('10000.00')
    s.commission_rate = Decimal ('0.05')
    s.base_salary = Decimal ('1000.00')
    print(s)
    print(f'{s.earnings():,.2f}')
if __name__ == "__main__":
    from decimal import Decimal
    main()
    