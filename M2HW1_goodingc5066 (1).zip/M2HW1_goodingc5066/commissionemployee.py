# -*- coding: utf-8 -*-
"""
Created on Tue Oct  6 21:36:09 2020
Chrystian Gooding
10/6/2020
M2HW1
This program will run a simple classes and inheritence example.
"""
"""Comissionemployee base class."""
#from decimal import Decimal

class CommissionEmployee:
    """An employee who gets paid commission based on gross sales."""
    def __init__(self, first_name, last_name, ssn, gross_sales,
                 commission_rate):
        self._first_name = first_name
        self._last_name = last_name
        self._ssn = ssn
        self.gross_sales = gross_sales #validate via property
        self.commission_rate = commission_rate #validate via property
        
    @property
    def first_name(self):
        return self._first_name
    
    @property
    def last_name(self):
        return self._last_name
    
    @property
    def ssn(self):
        return self._ssn
    
    @property 
    def gross_sales(self):
        return self._gross_sales
    
    @gross_sales.setter
    def gross_sales(self, sales):
        
        if sales < Decimal('0.00'):
            raise ValueError('Gross sales must be >= to 0')
            
        self._gross_sales = sales
        
    @property
    def commission_rate(self):
        return self._commission_rate
    
    @commission_rate.setter
    def commission_rate(self, rate):
        
        if not (Decimal('0.0') < rate < Decimal('1.0')):
            raise ValueError(
                    ' Interest rate must be greater than 0 and less than 1')
            
        self._commission_rate = rate
        
    def earnings(self):
        
        return self.gross_sales * self.commission_rate
    
    def __repr__(self):
        
        return (' CommissionEmployee: ' +
                f'{self.first_name} {self.last_name}\n'+
                f'social security number: {self.ssn}\n'+
                f'gross sales: {self.gross_sales:.2f}\n'+
                f'commission rate: {self.commission_rate:.2f}')
def main():
    #main is used to test the class
   
    c = CommissionEmployee('Sue', 'Jones', '333-33-333', Decimal('10000.00'),
                                                    Decimal('0.06')) 
    print("testing CommissionEmployee")
    print(c)
    
#        print(f'{c.earnings():,.2f}') 
#        c.gross_sales = Decimal('20000.00')
#        c.commission_rate = Decimal('0.1')
#        print(f'{c.earnings():,.2f}')    

if __name__ == "__main__":
    from decimal import Decimal
    main()
    



        