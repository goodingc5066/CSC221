# -*- coding: utf-8 -*-
"""
Created on Mon Sep 14 19:06:49 2020
Chrystian Gooding
9/14/2020
M2T1
This program holds coordinate pairs(x and y)
""" 
# This program is a simple test of a Coordinate class.
class Coordinate(object):
    # holds a coordinate pair, x and y values
    def __init__(self, x , y):
        # set the x and y values
        self.x = x
        self.y = y

    def __str__(self):
        # a string representation of the object
        rep = "<" + str(self.x) + "," + str(self.y) + ">"
        return rep
    
    def distance(self, other):
        """ Returns the euclidean distance between two points """
        # see pythangorean theorem
        x_diff_sq = (self.x-other.x)**2
        y_diff_sq = (self.y-other.y)**2
        return (x_diff_sq + y_diff_sq)**0.5
    
    