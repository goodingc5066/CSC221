# -*- coding: utf-8 -*-
"""
Created on Sun Sep 27 09:31:27 2020

@author: Chrystian   
CSC 221
M2LAB2
Chrystian Gooding
9/27/20      
"""
#for bronze - create a deck shuffle and display it
from deck import DeckOfCards
deck_of_cards = DeckOfCards()
deck_of_cards.shuffle()
my_card = deck_of_cards.deal_card()
print(my_card)
print(deck_of_cards)

# for silver and gold - we'll need to use the console magic %matplotlib
# so the rest is in the console

#code used for silver
"""
from deck import DeckOfCards
deck_of_cards = DeckOfCards()
%matplotlib
from pathlib import Path
path = Path(".").joinpath('card_imagaes')
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
figure, axes_list = plt.subplots(nrows=4, ncols=13)
for axes in axes_list.ravel():
    axes.get_xaxis().set_visible(False)
    axes.get_yaxis().set_visible(False)
    image_name = deck_of_cards.deal_card().image_name
    img = mpimg.imread(str(path.joinpath(image_name).resolve()))
    axes.imshow(img)
figure.tight_layout()
"""

#code used for gold
"""
from deck import DeckOfCards
deck_of_cards = DeckOfCards()
%matplotlib
from pathlib import Path
path = Path(".").joinpath('card_imagaes')
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
figure, axes_list = plt.subplots(nrows=2, ncols=5)
for axes in axes_list.ravel():
    axes.get_xaxis().set_visible(False)
    axes.get_yaxis().set_visible(False)
    image_name = deck_of_cards.deal_card().image_name
    img = mpimg.imread(str(path.joinpath(image_name).resolve()))
    axes.imshow(img)
figure.tight_layout()
"""