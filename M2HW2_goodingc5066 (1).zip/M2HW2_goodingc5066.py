# -*- coding: utf-8 -*-
"""
Chrystian Gooding
10/14/2020
M2HW2
Unit Testing with Doctest
"""
# accountdoctest.py
"""Account class defination."""
from decimal import Decimal

class Account:
    """Account class for demonstrating doctest."""
    
    def __init__(self, name, balance):
        """Initialize an Account object.
        
        >>> account1 = Account('John Green', Decimal('50.00'))
        >>> account1.name
        'John Green'
        >>> account1.balance
        Decimal('50.00')
        
        The balance argument must be greater than or equal to 0.
        >>> account2 = Account('John Green', Decimal('-50.00'))
        Traceback (most recent call last):
            ...
        ValueError: Initial balance must be >= to 0.00.
        >>> account2 = Account('', Decimal('20.00'))
        Traceback (most recent call last):
            ...
        ValueError: Name cannot be empty
        """
        if name == '':
            raise ValueError ('Name cannot be empty')
        # if balance is less than 0.00, raise an exception
        if balance < Decimal ('0.00'):
            raise ValueError('Initial balance must be >= to 0.00.')
            
        self.name = name
        self.balance = balance
        
    def deposit(self, amount):
        """Deposit money to the account.
        
        >>> account1 = Account('John Green', Decimal('50.00'))
        >>> account1.deposit(Decimal('10.55'))
        >>> account1.balance
        Decimal('60.55')
        
        >>> account1.deposit(Decimal('-100.00'))
        Traceback (most recent call last):
            ...
        ValueError: amount must be positive.
        """
        
        # if amount is less than 0.00, raise an exception
        if amount < Decimal('0.00'):
            raise ValueError('amount must be positive.')
            
        self.balance += amount
        
   
    
    def withdraw(self, amount):
        """Withdraw money from the account.
        
        >>> account1 = Account('John Green', Decimal('100.00'))
        >>> account1.withdraw(Decimal('20.00'))
        >>> account1.balance
        Decimal('80.00')
        
        >>> account1.withdraw(Decimal('150.00'))
        Traceback (most recent call last):
            ...
        ValueError: withdraw amount cannot be more than balance.
        """
        
        # if amount is more than 100.00, raise an exception
        if amount > Decimal('100.00'):
            raise ValueError('withdraw amount cannot be more than balance.')
            
        self.balance -= amount

        
if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)